package com.ecomarket.Inventory_Service.service.impl;


import com.ecomarket.Inventory_Service.model.Inventory;
import com.ecomarket.Inventory_Service.repository.InventoryRepository;
import com.ecomarket.Inventory_Service.service.InventoryService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class InventoryServiceImpl implements InventoryService {

    private final InventoryRepository repository;

    public InventoryServiceImpl(InventoryRepository repository) {
        this.repository = repository;
    }

    @Override
    public Inventory createInventory(Inventory inventory) {
        return repository.save(inventory);
    }

    @Override
    public Inventory updateInventory(Long id, Inventory inventory) {
        Inventory existing = repository.findById(id).orElseThrow();
        existing.setProductId(inventory.getProductId());
        existing.setQuantity(inventory.getQuantity());
        existing.setLocation(inventory.getLocation());
        return repository.save(existing);
    }

    @Override
    public void deleteInventory(Long id) {
        repository.deleteById(id);
    }

    @Override
    public List<Inventory> getAllInventory() {
        return repository.findAll();
    }

    @Override
    public Inventory getInventoryById(Long id) {
        return repository.findById(id).orElse(null);
    }

    @Override
    public Inventory reduceStock(Long productId, int amount) {
        Inventory inventory = repository.findByProductId(productId);
        if (inventory != null && inventory.getQuantity() >= amount) {
            inventory.setQuantity(inventory.getQuantity() - amount);
            return repository.save(inventory);
        }
        throw new RuntimeException("Not enough stock or product not found.");
    }
}
